//
//  MyMoveTo.h
//  Genoma
//
//  Created by Giovanni Amati on 13/10/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "CCIntervalAction.h"
#import "CCDirector.h"
#import "CCCamera.h"
#import "CGPointExtension.h"

@interface MyMoveTo : CCMoveTo
{

}

@end