//
//  BabelAppDelegate.h
//  Babel
//
//  Created by Giovanni Amati on 02/12/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SharedData.h"

@interface BabelAppDelegate : NSObject <UIApplicationDelegate>
{
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end