//
//  MyMoveTo.m
//  Genoma
//
//  Created by Giovanni Amati on 13/10/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "MyMoveTo.h"

enum {
	kTagGameLayer = 0,
	kTagTileMap = 5,
	kTagPlayerSel = 7,
};

@implementation MyMoveTo

// override methods
-(void) update:(ccTime)t
{	
	// move target (same original cocos update)
	float x = startPosition.x + delta.x * t;
	float y = startPosition.y + delta.y * t;
	[target setPosition:ccp(x, y)];
	
	id layer = [[[CCDirector sharedDirector] runningScene] getChildByTag:kTagGameLayer];
	id tilemap = [layer getChildByTag:kTagTileMap];
	id selection = [tilemap getChildByTag:kTagPlayerSel];
	[selection setPosition:ccp(x, y)];
	
	// layer's camera follow taget
	//CGSize s = [[CCDirector sharedDirector] displaySize];
	//x -= s.width / 4; // camera pos standard relative to target
	//y += s.height / 4;
	
	// move camera
	//id layer = [[[CCDirector sharedDirector] runningScene] getChildByTag:kTagGameLayer];
	//[[layer camera] setCenterX:x centerY:y centerZ:0];
	//[[layer camera] setEyeX:x eyeY:y eyeZ:CCCamera.getZEye];
}

@end