//
//  MySequence.h
//  Genoma
//
//  Created by Giovanni Amati on 15/10/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "CCIntervalAction.h"

@interface MySequence : CCSequence
{

}

+(id) actions:(NSArray *)acts;

@end
