//
//  main.m
//  Babel
//
//  Created by Giovanni Amati on 02/12/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
	NSAutoreleasePool *pool = [NSAutoreleasePool new];
	int retVal = UIApplicationMain(argc, argv, nil, @"BabelAppDelegate");
	[pool release];
	return retVal;
}
